import csv
import datetime
import smtplib
from influxdb import InfluxDBClient
import numpy as np

class DataCollector:
    def __init__(self, day, database_name="usinalog", measurement="webdata_now"):
        self.client = InfluxDBClient(host='192.168.5.2', port=8086)
        self.database_name = database_name
        self.measurement = measurement
        self.client.switch_database(self.database_name)
        self.day = day  # O dia informado pelo usuário para buscar os dados
        self.int_csv_file = "int_calc.csv"
        self.data_reg_csv_file = "data_reg.csv"
    
    def get_data_for_day(self):
        """Busca todos os dados de um dia informado."""
        start_time = f"{self.day}T00:00:00Z"
        end_time = f"{self.day}T23:59:59Z"
        
        print(f"Query executada: SELECT time, Energia FROM {self.measurement} "
          f"WHERE time >= '{start_time}' AND time <= '{end_time}'")
        
        query = (f"SELECT time, Energia FROM {self.measurement} "
                 f"WHERE time >= '{start_time}' AND time <= '{end_time}'")
        
        result = self.client.query(query)
        points = list(result.get_points())
        
        return points

    def save_data_to_csv(self, data_points):
        """Armazena as leituras no arquivo .csv."""
        with open(self.int_csv_file, mode='w', newline='') as file:
            writer = csv.writer(file)
            for point in data_points:
                timestamp = point['time']
                value = point['Energia']
                writer.writerow([timestamp, value])
    
    def calculate_area(self):
        """Calcula a área da curva formada pelos dados do CSV e salva em outro CSV."""
        times = []
        values = []
        
        with open(self.int_csv_file, mode='r') as file:
            reader = csv.reader(file)
            for row in reader:
                time_str = row[0]
                value = float(row[1])
                
                # Convertendo o tempo para datetime e depois para timestamp para cálculos
                time_obj = datetime.datetime.strptime(time_str, "%Y-%m-%dT%H:%M:%S.%fZ")
                times.append(time_obj.timestamp())
                values.append(value)
        
        # Calculando a área utilizando a regra dos trapézios
        area = np.trapz(values, times)
        
        # Salvando o resultado da integração
        current_hour = datetime.datetime.now().strftime('%H:00:00')
        with open(self.data_reg_csv_file, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([area])
    
    def send_email(self):
        """Envia o arquivo data_reg.csv via e-mail ao final do dia."""
        subject = f"solar_data_reg {self.day}"
        body = "Segue em anexo o arquivo de registros do dia."
        sender_email = "picolloiot@gmail.com"
        receiver_email = "renatopicollo@gmail.com"
        password = "1029384756Joll$"

        message = f"Subject: {subject}\n\n{body}"

        with open(self.data_reg_csv_file, 'r') as file:
            file_data = file.read()

        try:
            with smtplib.SMTP('smtp.gmail.com', 587) as server:
                server.starttls()
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email, message)
            print("E-mail enviado com sucesso.")
        except Exception as e:
            print(f"Erro ao enviar e-mail: {e}")

    def run(self):
        """Executa o processo completo para o dia informado."""
        print(f"Buscando dados para o dia {self.day}...")
        print (self.measurement)
        data_points = self.get_data_for_day()
        print(f"Encontrado {len(data_points)} pontos de dados.")
        
        # Armazenar os dados no CSV
        self.save_data_to_csv(data_points)
        
        # Calcular a área
        self.calculate_area()
        
        # Enviar o arquivo por e-mail
        print(f"Enviando arquivo por e-mail...")
        self.send_email()
        print(f"Processo concluído.")

# Exemplo de execução
if __name__ == "__main__":
    # Usuário deve informar o dia no formato 'YYYY-MM-DD'
    dia_informado = "2024-10-08"
    
    collector = DataCollector(day=dia_informado)
    collector.run()
