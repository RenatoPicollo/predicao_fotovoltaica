import csv
import time
from datetime import datetime
from influxdb import InfluxDBClient
from scipy.integrate import simps
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

class SolarDataLogger:
    def __init__(self, db_host, db_port, db_name, measurement, csv_filename='int_calc.csv'):
        self.client = InfluxDBClient(host=db_host, port=db_port, database=db_name)
        self.measurement = measurement
        self.csv_filename = csv_filename
        self.data_reg_filename = 'data_reg.csv'

    def start_reading(self):
        """Inicia a leitura do banco de dados e grava os dados no CSV"""
        while True:
            current_time = datetime.now()

            # Verifica se a hora mudou (hora cheia)
            if current_time.minute == 0 and current_time.second == 0:
                self.read_data_and_store_in_csv()
                time.sleep(1)

            # Verifica se é o final de uma hora cheia para integrar e salvar o resultado
            if current_time.minute == 59 and current_time.second == 59:
                self.calculate_integration()
                time.sleep(1)

            # Verifica se é o final do dia para enviar o e-mail
            if current_time.hour == 23 and current_time.minute == 59 and current_time.second == 59:
                self.send_email()
                time.sleep(1)

    def read_data_and_store_in_csv(self):
        """Realiza a leitura do InfluxDB e armazena os dados no CSV"""
        query = f"SELECT * FROM {self.measurement} WHERE time >= now() - 1h"
        result = self.client.query(query)

        with open(self.csv_filename, mode='w', newline='') as file:
            writer = csv.writer(file)
            for point in result.get_points():
                timestamp = point['time']
                value = point['value']
                writer.writerow([timestamp, value])
        
        print(f"Dados armazenados no arquivo {self.csv_filename}")

    def calculate_integration(self):
        """Calcula a integração da curva e armazena no arquivo de registro"""
        times = []
        values = []

        with open(self.csv_filename, mode='r') as file:
            reader = csv.reader(file)
            for row in reader:
                times.append(self.convert_time_to_seconds(row[0]))
                values.append(float(row[1]))

        # Usamos a regra do trapezoide ou Simpson para calcular a área
        area = simps(values, times)

        # Armazena a área e a hora atual no data_reg.csv
        with open(self.data_reg_filename, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([datetime.now().strftime('%Y-%m-%d %H:00:00'), area])
        
        print(f"Área integrada salva em {self.data_reg_filename}")

    def convert_time_to_seconds(self, time_str):
        """Converte o timestamp em segundos"""
        time_obj = datetime.strptime(time_str, "%Y-%m-%dT%H:%M:%S.%fZ")
        return time_obj.timestamp()

    def send_email(self):
        """Envia o arquivo data_reg.csv por e-mail"""
        email_user = 'seu_email@gmail.com'
        email_password = 'sua_senha'
        email_send = 'destinatario_email@gmail.com'

        subject = f'solar_data_reg {datetime.now().strftime("%Y-%m-%d")}'

        msg = MIMEMultipart()
        msg['From'] = email_user
        msg['To'] = email_send
        msg['Subject'] = subject

        body = 'Arquivo de integração diária da energia gerada.'
        msg.attach(MIMEText(body, 'plain'))

        attachment = open(self.data_reg_filename, 'rb')

        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f'attachment; filename= {self.data_reg_filename}')

        msg.attach(part)
        text = msg.as_string()

        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(email_user, email_password)

        server.sendmail(email_user, email_send, text)
        server.quit()
        
        print(f"Email enviado com o arquivo {self.data_reg_filename}")


# Configurações do banco de dados
db_host = '192.168.5.2'
db_port = 8086
db_name = 'usinalog'
measurement = 'webdata_now'

# Criação e execução do logger
logger = SolarDataLogger(db_host, db_port, db_name, measurement)
logger.start_reading()
