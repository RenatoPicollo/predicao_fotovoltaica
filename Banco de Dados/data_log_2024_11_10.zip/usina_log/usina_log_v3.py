import requests
import csv
import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from influxdb import InfluxDBClient
import numpy as np

class DataCollector:
    def __init__(self, day, database_name="usinalog", measurement="webdata_now"):
        self.client = InfluxDBClient(host='192.168.5.2', port=8086)
        self.database_name = database_name
        self.measurement = measurement
        self.client.switch_database(self.database_name)
        self.day = day  # O dia informado pelo usuário para buscar os dados
        self.int_csv_file = "/home/picolloiot/Documents/usina_log/int_calc.csv"
        self.data_reg_csv_file = "/home/picolloiot/Documents/usina_log/data_reg.csv"
        self.data_reg_daily_csv_file = f"/home/picolloiot/Documents/usina_log/data_reg_{day}.csv"
    
    def get_data_for_day(self):
        """Busca todos os dados de um dia informado."""
        start_time = f"{self.day}T00:00:00Z"
        end_time = f"{self.day}T23:59:59Z"
        
        print(f"Query executada: SELECT time, Energia FROM {self.measurement} "
          f"WHERE time >= '{start_time}' AND time <= '{end_time}'")
        
        query = (f"SELECT time, Energia FROM {self.measurement} "
                 f"WHERE time >= '{start_time}' AND time <= '{end_time}'")
        
        result = self.client.query(query)
        points = list(result.get_points())
        
        return points

    def save_data_to_csv(self, data_points):
        """Armazena as leituras no arquivo .csv."""
        with open(self.int_csv_file, mode='w', newline='') as file:
            writer = csv.writer(file)
            for point in data_points:
                timestamp = point['time']
                value = point['Energia']
                writer.writerow([timestamp, value])
    
    def integrate_by_hour(self, points):
        """Realiza a integração dos dados em intervalos de uma hora, ajusta o valor pelo número de pontos e salva no .csv"""
    
        start_time = None  # Variável para armazenar a hora inicial de cada intervalo de uma hora
        times = []
        values = []
        area_t = 0
    
        for point in points:
            time_str = point['time']
            value = point['Energia']
        
            # Convertendo o tempo para objeto datetime
            time_obj = datetime.datetime.strptime(time_str, "%Y-%m-%dT%H:%M:%S.%fZ")
        
            # Definir a hora inicial no primeiro ponto de dados
            if start_time is None:
                start_time = time_obj.replace(minute=0, second=0, microsecond=0)
        
            # Verifica se o tempo atual passou do intervalo de uma hora
            if time_obj >= start_time + datetime.timedelta(hours=1):
                if times and values:
                    # Calcula a área utilizando a regra dos trapézios
                    area = np.trapz(values, np.array(times) / (len(values)*60))
                
                    # Divide a área pelo número de pontos
                    area = round(area, 1)
                    area_t = area_t + area
                
                    # Salva o valor da integração no arquivo .csv
                    current_hour = start_time.strftime('%Y-%m-%d %H:00:00')
                    with open(self.data_reg_csv_file, mode='a', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerow([current_hour, area])
                        
                    # Salva o valor da integração no arquivo .csv diário
                    # current_hour = start_time.strftime('%H:00:00')
                    with open(self.data_reg_daily_csv_file, mode='a', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerow([current_hour, area])
            
                # Reinicia as variáveis para a próxima hora
                start_time += datetime.timedelta(hours=1)
                times = []
                values = []
        
            # Adiciona o tempo e o valor atual aos arrays
            times.append(time_obj.timestamp())
            values.append(value)
    
        # Realiza a integração da última hora, caso haja dados restantes
        if times and values:
            area = np.trapz(values, np.array(times) / (len(values)*60))
            area = round(area, 1)
            area_t = area_t + area
            current_hour = start_time.strftime('%Y-%m-%d %H:00:00')
            with open(self.data_reg_csv_file, mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([current_hour, area])
            with open(self.data_reg_daily_csv_file, mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([current_hour, area])
            with open(self.data_reg_daily_csv_file, mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["Total", round(area_t, 1)])            
    
    def send_email(self):
        # Configurações do Mailgun
        api_key = "4d686ce72ad5080ba44bf9d9e5db3170-5dcb5e36-0b4ddd88"  # Substitua pela sua API Key
        domain = "picolloiot.com"  # Substitua pelo seu domínio
        sender_email = "postmaster@sandbox456a76b999094af38fc5ceeb176bbac2.mailgun.org"  # E-mail do remetente (precisa estar verificado)
        recipient_email = "picolloiot@gmail.com"  # E-mail do destinatário

        # Configurando os dados do e-mail
        subject = f"solar_data_reg {self.day}"
        body = "Segue em anexo o arquivo de registros do dia."
        
        csv_file_path = self.data_reg_daily_csv_file

        # Enviar o e-mail
        response = requests.post(
            f"https://api.mailgun.net/v3/sandbox456a76b999094af38fc5ceeb176bbac2.mailgun.org/messages",
            auth=("api", api_key),
            data={"from": sender_email,
                       "to": recipient_email,
                       "subject": subject,
                       "text": body},
            files={"attachment": (csv_file_path, open(csv_file_path, "rb"))})

        # Verificando o resultado
        if response.status_code == 200:
            print("E-mail enviado com sucesso!")
        else:
            print(f"Erro ao enviar e-mail: {response.status_code} - {response.text}")

    def run(self):
        """Executa o processo completo para o dia informado."""
        print(f"Criando arquivo 'data_reg_{self.day}.csv'...")
        with open(self.data_reg_daily_csv_file, mode='w', newline='') as file:
            pass
        print(f"Buscando dados para o dia {self.day}...")
        print (self.measurement)
        data_points = self.get_data_for_day()
        print(f"Encontrado {len(data_points)} pontos de dados.")
        
        # Armazenar os dados no CSV
        self.save_data_to_csv(data_points)
        
        # Calcular a área
        self.integrate_by_hour(data_points)
        
        # Enviar o arquivo por e-mail
        print(f"Enviando arquivo por e-mail...")
        self.send_email()
        print(f"Processo concluído.")

# Exemplo de execução
if __name__ == "__main__":
    # Usuário deve informar o dia no formato 'YYYY-MM-DD'
    data_corrente = datetime.datetime.utcnow()
    dia_informado = (data_corrente - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
    
    collector = DataCollector(day=dia_informado)
    collector.run()
