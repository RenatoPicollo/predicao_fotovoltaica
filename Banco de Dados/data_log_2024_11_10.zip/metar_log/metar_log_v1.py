import requests
import datetime
import os
import json
import csv

class MetarData:
    def __init__(self, day, api_url, station_code):
        self.api_url = api_url
        self.station_code = station_code
        self.day = day
        self.metar_reg_csv_file = "/home/picolloiot/Documents/metar_log/metar_data_reg.csv"
        self.metar_reg_daily_csv_file = f"/home/picolloiot/Documents/metar_log/metar_data_reg_{day}.csv"

    # Método para consultar a API e obter os dados
    def get_metar_data(self):        
        response = requests.get(self.api_url)
        #print(response.status_code)
        #print(response.text.strip())

        if response.status_code == 200:
            data = json.loads(response.text.strip())
            
            if data["data"]["total"] > 0:  # Verifica se há dados
                metar_message = data["data"]["data"][0]["mens"]
                return metar_message  # Retorna a mensagem METAR
            else:
                self.send_error_email()
                return "NO DATA AVAILABLE"
            
        else:
            self.send_error_email()
            return "NO DATA AVAILABLE"

    # Método para validar os dados METAR
    def validate_metar_data(self, metar_data):
        if metar_data.startswith(f"METAR {self.station_code}"):
            # Extrai o timestamp, ex: "091200Z"
            timestamp = metar_data.split()[2]
            day = timestamp[:2]
            hour = timestamp[2:4]

            # Pega o dia e a hora UTC atuais
            now_utc = (datetime.datetime.utcnow() + datetime.timedelta(hours=0))
            current_day = now_utc.strftime("%d")
            current_hour = now_utc.strftime("%H")

            # Valida se o dia e a hora batem com os valores UTC atuais
            if day == current_day and hour == current_hour:
                return True
        return False

    # Método para salvar os dados no arquivo .csv
    def save_to_file(self, metar_data):
        current_time_utc = (datetime.datetime.utcnow() + datetime.timedelta(hours=0)).strftime("%d/%m/%Y %H:00")
        with open(self.metar_reg_csv_file, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([current_time_utc, metar_data])
        with open(self.metar_reg_daily_csv_file, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([current_time_utc, metar_data])        

    # Método principal que faz todas as operações
    def process_metar(self):
        metar_data = self.get_metar_data()

        if self.validate_metar_data(metar_data):
            hora_corrente = (datetime.datetime.utcnow() + datetime.timedelta(hours=0)).strftime("%H")
            if (hora_corrente == str(00)):
                with open(self.data_reg_daily_csv_file, mode='w', newline='') as file:
                    pass
                self.save_to_file(metar_data)
            elif (hora_corrente == str(23)):
                self.save_to_file(metar_data)
                self.send_email()
            else:
                self.save_to_file(metar_data)                                
        else:
            self.send_error_email()
            self.save_to_file("NO DATA AVAILABLE")
            
    def send_email(self):
        # Configurações do Mailgun
        api_key = "4d686ce72ad5080ba44bf9d9e5db3170-5dcb5e36-0b4ddd88"  # Substitua pela sua API Key
        domain = "picolloiot.com"  # Substitua pelo seu domínio
        sender_email = "postmaster@sandbox456a76b999094af38fc5ceeb176bbac2.mailgun.org"  # E-mail do remetente (precisa estar verificado)
        recipient_email = "picolloiot@gmail.com"  # E-mail do destinatário

        # Configurando os dados do e-mail
        subject = f"metar_data_reg {self.day}"
        body = "Segue em anexo o arquivo de registros do dia."
        
        csv_file_path = self.metar_reg_daily_csv_file

        # Enviar o e-mail
        response = requests.post(
            f"https://api.mailgun.net/v3/sandbox456a76b999094af38fc5ceeb176bbac2.mailgun.org/messages",
            auth=("api", api_key),
            data={"from": sender_email,
                       "to": recipient_email,
                       "subject": subject,
                       "text": body},
            files={"attachment": (csv_file_path, open(csv_file_path, "rb"))})

        # Verificando o resultado
        if response.status_code == 200:
            print("E-mail enviado com sucesso!")
        else:
            print(f"Erro ao enviar e-mail: {response.status_code} - {response.text}")
            
    def send_error_email(self):
        # Configurações do Mailgun
        api_key = "4d686ce72ad5080ba44bf9d9e5db3170-5dcb5e36-0b4ddd88"  # Substitua pela sua API Key
        domain = "picolloiot.com"  # Substitua pelo seu domínio
        sender_email = "postmaster@sandbox456a76b999094af38fc5ceeb176bbac2.mailgun.org"  # E-mail do remetente (precisa estar verificado)
        recipient_email = "picolloiot@gmail.com"  # E-mail do destinatário

        # Configurando os dados do e-mail
        current_time_utc = (datetime.datetime.utcnow() + datetime.timedelta(hours=0)).strftime("%d/%m/%Y %H:00")
        subject = "NO DATA AVAILABLE"
        body = f"Foi identificado indisponibilidade de dados de METAR às {current_time_utc}. Verificar registro CSV para atualização."

        # Enviar o e-mail
        response = requests.post(
            f"https://api.mailgun.net/v3/sandbox456a76b999094af38fc5ceeb176bbac2.mailgun.org/messages",
            auth=("api", api_key),
            data={"from": sender_email,
                       "to": recipient_email,
                       "subject": subject,
                       "text": body})

        # Verificando o resultado
        if response.status_code == 200:
            print("E-mail de erro enviado com sucesso!")
        else:
            print(f"Erro ao enviar e-mail: {response.status_code} - {response.text}")             

# Classe para gerenciar a aplicação
class MetarApp:
    def __init__(self, day, api_url, station_code):
        self.metar_data = MetarData(day, api_url, station_code)

    # Método que inicia a aplicação
    def run(self):
        self.metar_data.process_metar()

# Executa o programa
if __name__ == "__main__":
    day = (datetime.datetime.utcnow() + datetime.timedelta(hours=0)).strftime("%Y-%m-%d")
    api_key = "ABTz2jQKZ2a6hbenG00IhXO48CvuHkM7KygTXtd7"  # Substitua pela sua KEY API
    api_url = f"https://api-redemet.decea.mil.br/mensagens/metar/SBSC?api_key={api_key}"
    station_code = "SBSC"

    app = MetarApp(day, api_url, station_code)
    app.run()
