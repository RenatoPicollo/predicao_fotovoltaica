import requests
import csv
from datetime import datetime

class MetarRequest:
    def __init__(self, local: str, msg: str, data_ini: str, data_fim: str):
        self.url = "http://redemet.decea.gov.br//api/consulta_automatica/index.php"
        self.params = {
            "local": local,
            "msg": msg,
            "data_ini": data_ini,
            "data_fim": data_fim
        }
        # Extraindo a data da requisição para nome do arquivo
        self.request_date = datetime.strptime(data_ini[:8], "%Y%m%d").strftime("%Y-%m-%d")
        self.metar_reg_daily_csv_file = f"/home/picolloiot/Documents/metar_log/metar_data_reg_{self.request_date}.csv"
    
    def fetch_data(self):
        try:
            response = requests.get(self.url, params=self.params)
            if response.status_code == 200:
                return response.text.split("\n")  # Divide as linhas da resposta
            else:
                return []
        except requests.exceptions.RequestException as e:
            return []

    @staticmethod
    def format_metar_entry(entry: str) -> str:
        """ Converte o formato da resposta para o desejado """
        try:
            parts = entry.split(" - ")
            if len(parts) != 2:
                return entry  # Retorna como está se não for no formato esperado
            
            # Extrai a data e hora no formato AAAAMMDDHH
            raw_datetime = parts[0]
            formatted_datetime = datetime.strptime(raw_datetime, "%Y%m%d%H").strftime("%d/%m/%Y %H:%M")
            return f"{formatted_datetime},{parts[1]}"
        except Exception as e:
            return entry  # Retorna a entrada original em caso de erro

    def save_to_csv(self):
        filename =  self.metar_reg_daily_csv_file
        data = self.fetch_data()
        if not data:
            print("Nenhum dado para salvar.")
            return
        
        with open(filename, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file, quoting=csv.QUOTE_NONE)
            for entry in data:
                if entry.strip():  # Evita linhas vazias
                    writer.writerow(self.format_metar_entry(entry).split(","))
        
        print(f"Dados salvos em {filename}")

if __name__ == "__main__":
    metar = MetarRequest(local="sbsc", msg="metar", data_ini="2025032200", data_fim="2025032223")
    metar.save_to_csv()
